package com.istech.lighthouse.model.comparative

data class BarChartHome(
    val `data`: BarChartDataForComparitive,
    val message: String,
    val success: Boolean
)
