package com.istech.lighthouse.model.ongoingdata

data class OnGoingReportValues(
    val `data`: OnGoingReportData,
    val message: String,
    val success: Boolean
)