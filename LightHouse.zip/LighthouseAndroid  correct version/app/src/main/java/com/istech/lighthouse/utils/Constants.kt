package com.istech.lighthouse.utils

class Constants {
    
    companion object {
        const val CONSUMER_ID = "consumerID"
        const val AMOUNT = "amount"
        const val TRANSACTION_ID = "transactionID"
        const val STATUS = "status"
    }
}