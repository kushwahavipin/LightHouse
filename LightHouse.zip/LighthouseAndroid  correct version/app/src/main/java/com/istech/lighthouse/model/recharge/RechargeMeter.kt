package com.istech.lighthouse.model.recharge

data class RechargeMeter(
    val success: Boolean,
    val message: String
)