package com.istech.lighthouse.model.login

data class LoginModel(
    val `data`: Data,
    val message: String,
    val success: Boolean

)
