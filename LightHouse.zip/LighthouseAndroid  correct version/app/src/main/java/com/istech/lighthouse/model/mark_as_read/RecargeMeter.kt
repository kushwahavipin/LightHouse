package com.istech.lighthouse.model.mark_as_read

data class MarkAsRead(
    val success: Boolean,
    val message: String
)
