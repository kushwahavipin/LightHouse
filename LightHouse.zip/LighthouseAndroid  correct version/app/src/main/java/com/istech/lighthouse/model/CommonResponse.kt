package com.istech.lighthouse.model

data class CommonResponse(
    val message: String,
    val success: Boolean
)