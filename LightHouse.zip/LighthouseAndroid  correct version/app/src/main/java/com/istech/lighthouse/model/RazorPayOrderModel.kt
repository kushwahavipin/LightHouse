package com.istech.lighthouse.model

data class RazorPayOrderModel(
    val success: Boolean,
    val message: String,
    val data:String
)
