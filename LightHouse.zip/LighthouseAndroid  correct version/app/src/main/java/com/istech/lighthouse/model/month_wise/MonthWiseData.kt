package com.istech.lighthouse.model.month_wise

data class MonthWiseData(
    val lable : String,
    val dgValue : Double,
    val gridValue : Double
)
