package com.istech.lighthouse.model.dashboard

data class DashboardModel(
    val `data`: Data,
    val message: String,
    val success: Boolean
)