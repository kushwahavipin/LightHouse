package com.istech.lighthouse.model.profile

data class ProfileModel(
    val `data`: Data,
    val message: String,
    val success: Boolean
)