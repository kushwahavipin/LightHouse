package com.istech.lighthouse.model.comparative

data class DgListPOJO(
    val date : String,
    val kwh : Int,
    val kvah : Int
)
