package com.istech.lighthouse.model.recharge

data class RechargeHome (
    val `data`: RechargeData,
    val message: String,
    val success: Boolean
        )