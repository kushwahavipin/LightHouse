package com.istech.lighthouse.model.statics

data class StaticsModel(
    val `data`: Data,
    val message: String,
    val success: Boolean
)